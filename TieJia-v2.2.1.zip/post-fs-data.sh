MODPATH="${0%/*}"
. $MODPATH/common_func.sh

# Our PIF zygisk binary is binary-patched at build time to read its dex/config
# from /data/adb/modules/tricky_store (our module dir) instead of the upstream
# hardcoded /data/adb/modules/playintegrityfix. So there is NO separate
# playintegrityfix folder to create here — everything lives under our module.
[ -f "$MODPATH/common_setup.sh" ] && . $MODPATH/common_setup.sh

# --- DenyList: intentionally NOT managed ---------------------------------
# We must never force "Enforce DenyList" on. With Zygisk Next / ReZygisk /
# NeoZygisk (the recommended setup) plus a hider like Shamiko, enforcement is
# meant to stay OFF — the Zygisk implementation does the hiding, and turning
# Magisk's enforcement on can actually break it. A previous version called
# `magisk --denylist enable` here, which flipped a toggle users deliberately
# keep off. Leave the user's DenyList state exactly as they set it.

# --- Security patch level (attestation + Build consistency) ---------------
# Writes /data/adb/tricky_store/security_patch.txt for the TEE attestation and
# pins ro.build.version.security_patch to match the spoofed fingerprint.
[ -f "$MODPATH/sync_patch.sh" ] && sh "$MODPATH/sync_patch.sh" boot 2>/dev/null

# --- Bootloader / verified boot props (required for STRONG, harmless if already correct) ---

# Samsung
resetprop_if_diff ro.boot.warranty_bit 0
resetprop_if_diff ro.vendor.boot.warranty_bit 0
resetprop_if_diff ro.vendor.warranty_bit 0
resetprop_if_diff ro.warranty_bit 0
resetprop_if_diff ro.boot.fmp_config 1
resetprop_if_diff ro.boot.dp_fw_check 1

# Realme
resetprop_if_diff ro.boot.realmebootstate green

# OnePlus
resetprop_if_diff ro.is_ever_orange 0

# Encryption state
resetprop_if_diff ro.crypto.state encrypted

# QEMU emulator detection — delete if present (tells apps this is not emulated)
delprop_if_exist ro.kernel.qemu 2>/dev/null || true
delprop_if_exist ro.boot.qemu 2>/dev/null || true
resetprop_if_diff ro.hardware.virtual_device 0

# VBMeta integrity chain (helps some devices reach DEVICE verdict)
resetprop_if_diff ro.boot.vbmeta.hash_alg sha256
resetprop_if_diff ro.boot.vbmeta.avb_version 1.0
resetprop_if_diff ro.boot.vbmeta.invalidate_on_error yes
for p in /dev/block/by-name/vbmeta /dev/block/by-name/vbmeta_a /dev/block/bootdevice/by-name/vbmeta; do
    [ -e "$p" ] && VBMETA_BLK="$p" && break
done
if [ -n "$VBMETA_BLK" ]; then
    VBMETA_SIZE=$(blockdev --getsize64 "$VBMETA_BLK" 2>/dev/null)
    [ -n "$VBMETA_SIZE" ] && resetprop_if_diff ro.boot.vbmeta.size "$VBMETA_SIZE"
fi

# Build tags / type — all variants (system, vendor, product, system_ext, etc.)
for PROP in $(resetprop | grep -oE 'ro.*.build.tags'); do
    resetprop_if_diff $PROP release-keys
done
for PROP in $(resetprop | grep -oE 'ro.*.build.type'); do
    resetprop_if_diff $PROP user
done

# Boot image build tags (some devices leak debug tags here)
resetprop_if_diff ro.bootimage.build.tags release-keys

# Partition verified flags — GMS checks these for tampering
for p in system vendor product system_ext odm; do
    resetprop_if_diff "partition.${p}.verified" 1
done
unset p

resetprop_if_diff ro.adb.secure 1
if ! $SKIPDELPROP; then
    delprop_if_exist ro.boot.verifiedbooterror
    delprop_if_exist ro.boot.verifyerrorpart
fi
delprop_if_exist crashrecovery.rescue_boot_count 2>/dev/null || true
resetprop_if_diff ro.boot.veritymode.managed yes
resetprop_if_diff ro.debuggable 0
resetprop_if_diff ro.force.debuggable 0
resetprop_if_diff ro.secure 1

# Strip custom-ROM build leaks (LineageOS, etc.) — they're a tell to PI
for PROP in ro.lineage.build.version ro.lineage.version ro.lineage.display.version \
            ro.modversion ro.cm.version; do
    delprop_if_exist "$PROP" 2>/dev/null || true
done

# Disable ROM-level spoof engines (PixelPropsUtils / pihooks / entryhooks)
# before GMS starts. Gated by config key daemon_rom_cleanup.
if [ -x "$MODPATH/rom_spoof_block.sh" ]; then
    sh "$MODPATH/rom_spoof_block.sh" 2>/dev/null || true
fi

# --- ReZygisk early init -------------------------------------------------
# Skip if Magisk built-in Zygisk is enabled (user chose stock Zygisk).
if [ "$ZYGISK_ENABLED" ]; then
  return 0
fi

# Manual trigger: fire post-fs-data.sh for all Zygisk modules.
# This is needed because ReZygisk replaces Magisk's built-in Zygisk loader.
if [ "$(which magisk)" ]; then
  cd "$MODPATH"
  for file in ../*; do
    if [ -d "$file" ] && [ -d "$file/zygisk" ] && ! [ -f "$file/disable" ]; then
      if [ -f "$file/post-fs-data.sh" ]; then
        cd "$file"
        log -p i -t "zygisk-sh" "Manually trigger post-fs-data.sh for $file"
        sh "$(realpath ./post-fs-data.sh)"
        cd "$MODPATH"
      fi
    fi
  done
fi

# Create temp dir for ReZygisk runtime
export TMP_PATH=/data/adb/rezygisk
rm -rf "$TMP_PATH"
mkdir -p "$TMP_PATH"
chmod 555 "$TMP_PATH"
chcon u:object_r:system_file:s0 "$TMP_PATH" 2>/dev/null

# Run ReZygisk post-fs-data.d hook (resets module.prop status)
[ -f /data/adb/post-fs-data.d/rezygisk.sh ] && sh /data/adb/post-fs-data.d/rezygisk.sh

# Start ptrace monitor (64-bit takes priority, fall back to 32-bit)
# Binaries are in TieJia's own bin/ dir
if [ -x "$MODPATH/bin/zygisk-ptrace64" ]; then
  "$MODPATH/bin/zygisk-ptrace64" monitor &
elif [ -x "$MODPATH/bin/zygisk-ptrace32" ]; then
  "$MODPATH/bin/zygisk-ptrace32" monitor &
fi
